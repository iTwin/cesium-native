.. cmake-module:: ../../Modules/FindLibinput.cmake
