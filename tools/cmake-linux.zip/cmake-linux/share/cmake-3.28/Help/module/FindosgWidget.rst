.. cmake-module:: ../../Modules/FindosgWidget.cmake
